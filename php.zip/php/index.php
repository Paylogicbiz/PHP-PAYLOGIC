<HTML>
<HEAD>
<script type="text/javascript" src="./js/jquery.min.js"></script>
<script type="text/javascript" src="./js/bootstrap_theme.min.js"></script>
<script type="text/javascript" src="./js/bootstrap.min.js"></script>

<link href="./css/bootstrap-theme.min.css" rel="stylesheet" />
<link href="./css/bootstrap.min.css" rel="stylesheet" />

<meta charset="utf-8" />
<title>PAYMENT GATEWAY</title>
<style>
.has-success .form-control, .has-success .control-label, .has-success .radio, .has-success .checkbox, .has-success .radio-inline, .has-success .checkbox-inline {
	color: #1cb78c !important;
}
.has-success .help-block {
	color: #1cb78c !important;
	border-color: #1cb78c !important;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #1cb78c;
}
.has-error .form-control, .has-error .help-block, .has-error .control-label, .has-error .radio, .has-error .checkbox, .has-error .radio-inline, .has-error .checkbox-inline {
	color: #f0334d;
	border-color: #f0334d;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #f0334d;
}
table {
	color: #333; /* Lighten up font color */
	font-family: "Raleway", Helvetica, Arial, sans-serif;
	font-weight: bold;
	width: 640px;
	border-collapse: collapse;
	border-spacing: 0;
}
td, th {
	border: 1px solid #CCC;
	height: 30px;
} /* Make cells a bit taller */
th {
	background: #F3F3F3; /* Light grey background */
	font-weight: bold; /* Make sure theyre bold */
	font-color: #1cb78c !important;
}
td {
	background: #FAFAFA; /* Lighter grey background */
	text-align: left;
	padding: 2px;/* Center our text */
}
label {
	font-weight: normal;
	display: block;
}
</style>
</HEAD>
<BODY>
<form class="form-horizontal" action="index.php" method="post"> 
  <input type="hidden" name="msg" id="msg" />
  <div class="container cs-border-light-blue"> 
    
    <!-- first line -->
    <div class="row pad-top"></div>
    <!-- end first line -->
    
    <div class="equalheight row" style="padding-top: 10px;">
      <div id="cs-main-body" class="cs-text-size-default pad-bottom">
        <div class="col-sm-9  equalheight-col pad-top">
          <div style="padding-bottom: 50px;">
            <h1>PAYLOGIC PHP</h1>
           <div class="row">
              <div class="col-sm-12">
                <legend>Transaction Details</legend>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">APP ID</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" name="APP_ID" id="APP_ID" value="7761220131130641"  />
                      </div>
                    </div>
                  </div>
                
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">SECRET KEY</label>
                      <div class="col-sm-8">
                        <input type="text"  class="form-control" name="key" id="key" value="d646baeff7bf4551"  />
                      </div>
                    </div>
                  </div>
          
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Order Number</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" name="order_no" id="order_no" value="RC17045677" />
                      </div>
                    </div>
                  </div>
                
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Amount</label>
                      <div class="col-sm-8">
                        <input type="text"  class="form-control" name="amount" id="amount" value="1200" />
                      </div>
                    </div>
                  </div>
                
                
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Currency Code</label>
                      <div class="col-sm-8">
                      
                      <input type="text"  class="form-control" name="currency" id="currency"  value="356" />
                    </div>
                  </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Transaction Type</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" name="txn_type" id="txn_type" value="SALE">
                      </div>
                    </div>
                  </div>
               
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">RETURN_URL</label>
                      <div class="col-sm-8">
           	        <input type="text" class="form-control" name="return_url" id="return_url" value="http://localhost/php/response.php">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-12">
                <legend>Customer Details</legend>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Customer Name</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="cust_name" name="cust_name" value="Mayur" />
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Email ID</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="email_id" name="email_id" value="test@gmail.com" />
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Mobile No</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="mobile_no" name="mobile_no" value="8286941557" />
                      </div>
                    </div>
                  </div>
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">CUST_ADDRESS</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="street_address" name="street_address" value="Delhi" />
                      </div>
                    </div>
                  </div>
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">CUST_ZIPCODE</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="zip_code" name="zip_code"  value="110032"/>
                      </div>
                    </div>
                  </div>
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group">
                  <div class="col-sm-10 col-sm-offset-2">
                    <button class="btn btn-primary btn-lg"
											style="display: inline-block; vertical-align: middle; vert-align: middle; float: none;" name="submit">Checkout</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</form>
</BODY>
</HTML>
<script type="text/javascript">
$(document).ready(function(e) {
   $("#order_no").val(Math.floor((Math.random() * 100000) + 1))
});
</script>

<?php 




if(isset($_POST['submit'])){





//Create a ARRAY for the REQUEST

$reqData = array();

$reqData['APP_ID'] =$_POST['APP_ID'];
$reqData['AMOUNT'] =$_POST['amount'];
$reqData['CURRENCY_CODE'] =$_POST['currency'];
$reqData['CUST_EMAIL'] =$_POST['email_id'];
$reqData['CUST_NAME'] =$_POST['cust_name'];
$reqData['CUST_PHONE'] =$_POST['mobile_no'];
$reqData['CUST_STREET_ADDRESS1'] =$_POST['street_address'];
$reqData['CUST_ZIP'] =$_POST['zip_code'];
$reqData['ORDER_ID'] =$_POST['order_no'];
$reqData['RETURN_URL'] =$_POST['return_url'];
$reqData['TXNTYPE'] =$_POST['txn_type'];



//Sort the request in ascending manner

ksort($reqData);




//Adding ~ and = as an requirement for the request

$all ='';

foreach ($reqData as $name => $value) {
    $all .= $name."=".$value."~";
    $data = substr($all,0,-1);
    $data .= $_POST['key'];
    $hash = strtoupper(hash('SHA256', $data,false));

}

print_r($data);

//$test = hash('SHA256', "abcd",false);




//Collecting Data into the HTML part and posting the request

echo '
<html>
<BODY OnLoad="OnLoadEvent();" >
<form name="form1" action="https://pg.paylogic.biz/v1/jsp/paymentrequest" method="post">
    <input type="hidden" name="APP_ID" value="'.$_POST['APP_ID'].'">
    <input type="hidden" name="ORDER_ID" value="'.$_POST['order_no'].'">
    <input type="hidden" name="AMOUNT" value="'.$_POST['amount'].'">
    <input type="hidden" name="TXNTYPE" value="'.$_POST['txn_type'].'">
    <input type="hidden" name="CUST_NAME" value="'.$_POST['cust_name'].'">
    <input type="hidden" name="CUST_STREET_ADDRESS1" value="'.$_POST['street_address'].'">
    <input type="hidden" name="CUST_ZIP" value="'.$_POST['zip_code'].'">
    <input type="hidden" name="CUST_PHONE" value="'.$_POST['mobile_no'].'">
    <input type="hidden" name="CUST_EMAIL" value="'.$_POST['email_id'].'">
    <input type="hidden" name="CURRENCY_CODE" value="356">
    <input type="hidden" name="RETURN_URL" value="'.$_POST['return_url'].'">
    <input type="hidden" name="HASH" value="'.$hash.'">
    </form>
    <script language="JavaScript">function OnLoadEvent(){document.form1.submit();}</script>
    </BODY>
    </HTML>';





}






?>