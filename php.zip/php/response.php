<?php



if(isset($_POST['RESPONSE_CODE']) != null )
{



$Date = $_POST['RESPONSE_DATE_TIME'];

$RESPONSE_CODE = $_POST['RESPONSE_CODE'];

if($_POST['RESPONSE_CODE'] == '000')
{
    $RESPONSE = "SUCESSFULL";
}else{
    $RESPONSE = "FAILED";
}

$STATUS = $_POST['STATUS'];
$APP_ID = $_POST['APP_ID'];
$TXN_ID = $_POST['TXN_ID'];
$TXNTYPE=$_POST['TXNTYPE'];
$RETURN_URL=$_POST['RETURN_URL'];
$ORDER_ID=$_POST['ORDER_ID'];


$dattm = str_replace("+"," ",$Date);

$response = array();

$response['RESPONSE_DATE_TIME'] =$dattm;
$response['RESPONSE_CODE'] =$_POST['RESPONSE_CODE'];
$response['STATUS'] =$_POST['STATUS'];
$response['APP_ID'] =$_POST['APP_ID'];
$response['TXN_ID'] =$_POST['TXN_ID'];
$response['TXNTYPE'] =$_POST['TXNTYPE'];
$response['RETURN_URL'] =$_POST['RETURN_URL'];
$response['ORDER_ID'] =$_POST['ORDER_ID'];




if(isset($_POST['ACQ_ID'])){
   $response['ACQ_ID'] =$_POST['ACQ_ID'];
}
if(isset($_POST['CARD_MASK'])){
   $response['CARD_MASK'] =$_POST['CARD_MASK'];
}
if(isset($_POST['DUPLICATE_YN'])){
   $response['DUPLICATE_YN'] =$_POST['DUPLICATE_YN'];
}
if(isset($_POST['MOP_TYPE'])){
   $response['MOP_TYPE'] =$_POST['MOP_TYPE'];
}
if(isset($_POST['PAYMENT_TYPE'])){
   $response['PAYMENT_TYPE'] =$_POST['PAYMENT_TYPE'];
}
if(isset($_POST['RESPONSE_MESSAGE'])){
   $response['RESPONSE_MESSAGE'] =$_POST['RESPONSE_MESSAGE'];
}
if(isset($_POST['CUST_PHONE'])){
   $response['CUST_PHONE'] =$_POST['CUST_PHONE'];
}
if(isset($_POST['CUST_NAME'])){
   $response['CUST_NAME'] =$_POST['CUST_NAME'];
}
if(isset($_POST['CUST_EMAIL'])){
   $response['CUST_EMAIL'] =$_POST['CUST_EMAIL'];
}
if(isset($_POST['CURRENCY_CODE'])){
   $response['CURRENCY_CODE'] =$_POST['CURRENCY_CODE'];
}
if(isset($_POST['AMOUNT'])){
   $response['AMOUNT'] =$_POST['AMOUNT'];
}
if(isset($_POST['RRN'])){
   $response['RRN'] =$_POST['RRN'];
}
if(isset($_POST['ORIG_TXN_ID'])){
   $response['ORIG_TXN_ID'] =$_POST['ORIG_TXN_ID'];
}
if(isset($_POST['AUTH_CODE'])){
   $response['AUTH_CODE'] =$_POST['AUTH_CODE'];
}


// print_r($response);
// exit;

ksort($response);


$all ='';

foreach ($response as $name => $value) {
   $all .= $name."=".$value."~";
   $data = substr($all,0,-1);
   $data .= "d646baeff7bf4551"; // place secret key here as well
   $hash = strtoupper(hash('SHA256', $data));
}

if($_POST['HASH'] == $hash){

   $res = "HASHED MATCHED"; 

}else{
   $res = "HASHED MISMATCHED";

}


if(isset($_POST['RESPONSE_MESSAGE'])){
   $message = $_POST['RESPONSE_MESSAGE'];
}else{
   $message = "FAILED";
}


echo'<HTML>
<HEAD>
<script type="text/javascript" src="./js/jquery.min.js"></script>
<script type="text/javascript" src="./js/bootstrap_theme.min.js"></script>
<script type="text/javascript" src="./js/bootstrap.min.js"></script>

<link href="./css/bootstrap-theme.min.css" rel="stylesheet" />
<link href="./css/bootstrap.min.css" rel="stylesheet" />
   <meta charset="utf-8" />
   <title>Payment Service Provider | Merchant Accounts</title>
   <style>
      .has-success .form-control, .has-success .control-label, .has-success .radio, .has-success .checkbox, .has-success .radio-inline, .has-success .checkbox-inline {
      color: #1cb78c !important;
      }
      .has-success .help-block {
      color: #1cb78c !important;
      border-color: #1cb78c !important;
      box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #1cb78c;
      }
      .has-error .form-control, .has-error .help-block, .has-error .control-label, .has-error .radio, .has-error .checkbox, .has-error .radio-inline, .has-error .checkbox-inline {
      color: #f0334d;
      border-color: #f0334d;
      box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #f0334d;
      }
      table {
      color: #333; /* Lighten up font color */
      font-family: "Raleway", Helvetica, Arial, sans-serif;
      font-weight: bold;
      width: 640px;
      border-collapse: collapse;
      border-spacing: 0;
      }
      td, th {
      border: 1px solid #CCC;
      height: 30px;
      } /* Make cells a bit taller */
      th {
      background: #F3F3F3; /* Light grey background */
      font-weight: bold; /* Make sure theyre bold */
      font-color: #1cb78c !important;
      }
      td {
      background: #FAFAFA; /* Lighter grey background */
      text-align: left;
      padding: 2px;/* Center our text */
      }
      label {
      font-weight: normal;
      display: block;
      }
   </style>
</HEAD>
<BODY>
   <div class="container cs-border-light-blue">
      <!-- first line -->
      <div class="row pad-top"></div>
      <!-- end first line -->
      <div class="equalheight row" style="padding-top: 10px;">
         <div id="cs-main-body" class="cs-text-size-default pad-bottom">
            <div class="col-sm-9  equalheight-col pad-top">
               <div style="padding-bottom: 50px;">
                  <h1>PAYLOGIC RESPONSE!</h1>
                  <div class="row">
                     <div class="col-sm-12">
                        <legend>Your payment is '.$message.' Here is the details for it</legend>
                     </div>
                     <div class="row">
                        <div class="col-sm-6">
                           <div class="form-group">
                              <label class="control-label col-sm-4">Order Number</label>
                              <div class="col-sm-8">
                                 <legend>'.$_POST['ORDER_ID'].'</legend>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-6">
                           <div class="form-group">
                              <label class="control-label col-sm-4">APP_ID</label>
                              <div class="col-sm-8">
                                 <legend>'.$_POST['APP_ID'].'</legend>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-sm-6">
                              <div class="form-group">
                                 <label class="control-label col-sm-4">Transaction ID</label>
                                 <div class="col-sm-8">
                                    <legend>'.$_POST['TXN_ID'].'</legend>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-6">
                              <div class="form-group">
                                 <label class="control-label col-sm-4">STATUS</label>
                                 <div class="col-sm-8">
                                    <legend>'.$_POST['STATUS'].'</legend>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-sm-6">
                              <div class="form-group">
                                 <label class="control-label col-sm-4">DATE AND TIME</label>
                                 <div class="col-sm-8">
                                    <legend>'.$dattm.'</legend>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                           <div class="col-sm-6">
                              <div class="form-group">
                                 <label class="control-label col-sm-4">HASH</label>
                                 <div class="col-sm-8">
                                    <legend>'.$res.'</legend>
                                 </div>
                              </div>
                           </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   </form>
</BODY>
</HTML>';


}else{
    echo "NO DATA FOUND Please Retry Again";
}

?>